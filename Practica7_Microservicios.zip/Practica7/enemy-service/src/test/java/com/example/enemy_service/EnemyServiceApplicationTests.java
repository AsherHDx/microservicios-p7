package com.example.enemy_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnemyServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
